# Exemple de Prototype #

En aquest projecte hi ha un exemple de Prototype a Java

### Compilació i funcionament ###

A Linux i OSX:

```
./compile.sh
```

A Windows Powershell:

```
.\compile.bat
```

Or, from Visual Studio Code:

```
"Terminal > Run task > Compile Project"

```